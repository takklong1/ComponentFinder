# 元件快查 ComponentFinder — 手机端构建指引（AndroidIDE）

工程：`/sdcard/Download/RikkaHub-MCP/ComponentFinder`
技术栈：AGP 8.5.2 + Gradle 8.7+ + JDK 17 + Kotlin 1.9.24 + Compose 1.5.14 + Room(kapt) + CameraX + ML Kit

---

## 0. 为什么不能在手机内置编译链上跑

`compile_kotlin` / `build_dex` / `build_apk` 那条链（McpFileHub 内置）**不支持**：

- Compose 编译器插件（`androidx.compose.compiler:compiler`，必须用 `-Xplugin` 传给 kotlinc）
- kapt（Room 的 `@Database` / `@Dao` 注解处理）

两者缺一，Compose 版就编译不出来。所以必须用**真 Gradle**。

---

## 1. 装 AndroidIDE

- 官方 GitHub Releases：`https://github.com/androidide/androidide/releases`（下最新 `AndroidIDE-vX.X.X.apk`）
- GitHub 打不开就换镜像站搜同名包；或 IzzyOnDroid F-Droid 源里也有

装好先给它 **存储权限**（要读写 /sdcard 里的工程）。

## 2. 首次初始化（大约 1GB 下载）

首次打开按提示走「Setup」，它会装：

| 组件 | 要求 |
|---|---|
| JDK | **必须 17**（AGP 8.x 的硬要求；设置里能看到版本，若显示 11 就在设置里装 JDK 17） |
| Android SDK | Platform **34** + Build-Tools **34.0.0** |
| Gradle | **8.7 或更高**（AGP 8.5.2 的最低要求） |

> ⚠️ AndroidIDE 的下载源是 Google / 官方服务器，国内直连大概率卡住。
> **建议把 AndroidIDE 加进你的代理 App 名单**（你本来就是分应用模式），下完再移出也行。
> 另外工程里的 `settings.gradle.kts` 我已经配好了阿里云镜像，**Gradle 拉依赖那一环不吃代理也没事**。

## 3. 打开工程

AndroidIDE → Open Project → 选 `/sdcard/Download/RikkaHub-MCP/ComponentFinder`（选**根目录**，不是 app/）。

等它索引完成（首次会 Building symbols，慢是正常的）。

## 4. 构建

方式一：点右上角的 ▶ / 🔨 构建按钮 → 选 `assembleDebug`

方式二：打开 AndroidIDE 的终端手动跑（更可控，能看到完整日志）

```sh
cd /sdcard/Download/RikkaHub-MCP/ComponentFinder
gradle assembleDebug --stacktrace
```

首次构建会下载约 **400~600MB** 依赖（Compose / Room / CameraX / ML Kit），10~30 分钟都有可能，之后就快了。

## 5. 产物

```
app/build/outputs/apk/debug/app-debug.apk
```

完整路径：`/sdcard/Download/RikkaHub-MCP/ComponentFinder/app/build/outputs/apk/debug/app-debug.apk`

用文件管理器点它安装即可（debug 包由 AGP 自动签名，不用额外配置）。

---

## 6. 排错对照表

| 报错 | 处理 |
|---|---|
| `Minimum supported Gradle version is 8.7` | AndroidIDE 设置里装/切 Gradle 8.7+；或告诉我把 AGP 降到 8.1.4 |
| `Android Gradle plugin requires Java 17` | AndroidIDE 设置里装并切换 **JDK 17** |
| `Could not find com.android.tools.build:aapt2 ... linux` 或 `aapt2: not executable` | arm64 设备经典坑。在 AndroidIDE 终端跑 `which aapt2` 拿到真实路径，然后把 `gradle.properties` 里那行 `android.aapt2FromMavenOverride=` 取消注释改成该路径 |
| 提示找不到 Gradle wrapper / `gradlew` | 工程没带 wrapper（需要联网才能生成）。在 AndroidIDE 终端跑 `gradle wrapper --gradle-version 8.7` 补上，之后 `./gradlew assembleDebug` 也能用 |
| `SDK location not found` | 工程根目录建 `local.properties`，写 `sdk.dir=<AndroidIDE 的 SDK 路径>`（AndroidIDE 设置里能看到路径） |
| 卡在 `Downloading https://dl.google.com/...` | 把 AndroidIDE 加进代理名单，或重跑（阿里云镜像已配，通常只剩 Google 上少数没镜像的包） |
| `OutOfMemoryError` / Java heap space | 把 `gradle.properties` 的 `-Xmx2560m` 调小成 `-Xmx1536m` 再试（或反过来，若 1.5G 不够就加大） |
| `Execution failed for task ':app:kaptDebugKotlin'` | 把完整报错贴给我 |
| 构建成功但装不上（`INSTALL_FAILED_...`） | 先卸载手机上同名旧版再装 |

---

## 7. 备选路线（AndroidIDE 走不通时）

1. **Termux + Gradle**：`pkg install openjdk-17 gradle`，再手动装 Android SDK cmdline-tools。
   坑点：官方 `aapt2` 只有 x86_64 版，arm64 上跑不了，得另找 arm64 的 aapt2 并用 `aapt2FromMavenOverride` 指过去。
2. **PC / Android Studio**：把整个 `ComponentFinder/` 拷到电脑，Android Studio 直接 Open（会自动补 gradle wrapper），或命令行 `gradle assembleDebug`。
3. **GitHub Actions**：把工程传上去，用 workflow 云端出包，我负责写 workflow 文件。

---

## 已经替你改过的地方（对照原始工程）

1. `settings.gradle.kts` — 加了阿里云 maven 镜像（gradle-plugin / google / public），国内直连能拉依赖
2. `gradle.properties` — 堆内存调到 2560m + `kotlin.compiler.execution.strategy=in-process`（手机端省内存），并预留了 aapt2 覆盖开关
3. `ui/history/HistoryScreen.kt` — 删掉了一个会**编译报错**的错误 import（`kotlinx.coroutines.flow.collectAsState`，该函数其实在 `androidx.compose.runtime`）
4. `ui/navigation/AppNav.kt` — **BOM 的 ViewModel 提升到 NavHost 外层**。原来导入页和结果页各自 `viewModel()`，会拿到两个不同实例 → 结果页永远空白
5. `domain/model/ComponentSpec.kt` — 「容值」按类型显示为「阻值」（电阻不再叫容值）

## 已知可后续优化（不影响构建）

- `assets/rules.json` 里部分通用规则匹配不到实际型号，例如 `CL10B104KB8NNNC`、`GRM188R71H104KA93D`、`VJ0603Y104KXXAT` 都没命中，需要按真实厂商料号规则补
- 没有应用图标（`AndroidManifest.xml` 未设 `android:icon`）→ 桌面显示系统默认图标
- `BrandSeriesMap`、`UnitConverter` 两个对象目前没被引用


---

## 8. 让 AI 自己跑构建：`_bridge/`（推荐）

AndroidIDE 是 GUI，我没法驱动它点按钮；Android 系统也不允许我（别的 uid 的 App）
去执行 Termux/AndroidIDE 里的 JDK/Gradle。所以做了个**文件当命令通道**的桥：

在 AndroidIDE 终端里粘一次（**不要关掉**）：

```sh
sh /sdcard/Download/RikkaHub-MCP/ComponentFinder/_bridge/loop.sh
```

之后 AI 侧往 `_bridge/cmd` 写一行命令 → 桥在工程目录执行 → 输出进 `_bridge/out.log`。
这样循环（改代码 → 构建 → 读报错 → 再改）能自动转，不用你来回点。

细节见 `_bridge/README.md`。
