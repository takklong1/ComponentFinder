# _bridge —— 让我（AI 侧）能自己跑构建的通道

## 为什么需要它

Android 上有硬限制，我这边**没法自己执行两条命令以外的东西**：

- McpFileHub 的 `exec_command` 跑在它自己的 uid 里，够不到 Termux / AndroidIDE 的 `$PREFIX`（里面才有 JDK、Gradle、aapt2）
- `/sdcard` 是 **noexec**，二进制没法放这里执行
- Android 10 起，targetSdk 29+ 的 App **禁止 execve 自己可写目录里的文件**

所以"真 JDK + 真 Gradle"只能在 **Termux / AndroidIDE 的终端**里跑 —— 那里没有 MCP。
这个桥就是替代品：**文件当命令通道**，我用 MT 管理器写文件、读文件，效果等于给了我一个终端。

## 怎么用（你只需要做一次）

在 **AndroidIDE 的终端**（或 Termux，如果那边装了 JDK+Gradle+SDK）里粘这一行，然后**别关掉**：

```sh
sh /sdcard/Download/RikkaHub-MCP/ComponentFinder/_bridge/loop.sh
```

看到它打印出 `java:` / `gradle:` / `aapt2:` 三行信息就说明桥活了 —— **把那三行发我**，我一眼就能看出工具链缺什么。

然后你就不用管了（AndroidIDE 不要划掉后台；终端被杀了就再粘一次）。

## 我这边怎么驱动

| 文件 | 方向 | 作用 |
|---|---|---|
| `cmd` | 我 → 你 | 我写一行命令进去，比如 `gradle assembleDebug --stacktrace` |
| `out.log` | 你 → 我 | 命令的完整 stdout/stderr |
| `exit_code` | 你 → 我 | 退出码，0 就是成功 |
| `done` | 你 → 我 | 执行完毕的标记（我靠它判断该读结果了） |

命令都是在工程根目录 `/sdcard/Download/RikkaHub-MCP/ComponentFinder` 下执行的。

## 例：一次完整构建

1. 我写 `cmd` → `gradle assembleDebug --stacktrace`
2. 桥执行，产物写到 `out.log`
3. 我读 `out.log` + `exit_code`
4. 有编译错误 → 我直接改 `/sdcard/.../app/src/...` 下的源码，再写一次 `cmd`
5. 直到 `exit_code` = 0，产物在 `app/build/outputs/apk/debug/app-debug.apk`

循环能自己转起来，你只需要在第一步粘那一次命令。
