#!/system/bin/sh
# 构建桥（poor man's MCP）：在 AndroidIDE / Termux 的终端里跑一次，之后就长期驻留。
# 之后 AI 侧（MT 管理器 / McpFileHub）只要往 _bridge/cmd 写一行命令，
# 这里就会在当前工程目录执行它，把输出写进 _bridge/out.log，并在 _bridge/done 打标记。
#
# 用法（在 AndroidIDE 终端里粘这一行）：
#   sh /sdcard/Download/RikkaHub-MCP/ComponentFinder/_bridge/loop.sh

DIR=/sdcard/Download/RikkaHub-MCP/ComponentFinder/_bridge
PROJ=/sdcard/Download/RikkaHub-MCP/ComponentFinder

mkdir -p "$DIR"
rm -f "$DIR/cmd" "$DIR/done" "$DIR/exit_code"

echo "==============================================="
echo " 构建桥已启动"
echo " 工程: $PROJ"
echo " 通道: $DIR/cmd   (写入一行命令即可执行)"
echo " 日志: $DIR/out.log"
echo " 停止: Ctrl+C 或关掉这个终端"
echo "==============================================="
echo "java:  $(command -v java  || echo '未找到')"
echo "gradle:$(command -v gradle|| echo '未找到')"
echo "aapt2: $(command -v aapt2 || echo '未找到（arm64 常见）')"
echo "ANDROID_HOME=${ANDROID_HOME:-未设置}  ANDROID_SDK_ROOT=${ANDROID_SDK_ROOT:-未设置}"
echo "-----------------------------------------------"

while true; do
  if [ -f "$DIR/cmd" ]; then
    CMD=$(cat "$DIR/cmd")
    rm -f "$DIR/cmd" "$DIR/done" "$DIR/exit_code"
    echo ""
    echo "[$(date +%H:%M:%S)] >>> $CMD"
    sh -c "cd $PROJ && $CMD" > "$DIR/out.log" 2>&1
    echo "$?" > "$DIR/exit_code"
    echo done > "$DIR/done"
    echo "[$(date +%H:%M:%S)] <<< 退出码 $(cat "$DIR/exit_code")，输出尾部："
    tail -n 20 "$DIR/out.log"
  fi
  sleep 2
done
