package com.example.componentfinder.bom

import android.content.Context
import com.example.componentfinder.data.RulesRepository
import com.example.componentfinder.domain.parser.ParserEngine

class BomRepository(context: Context) {
    private val parser = ParserEngine(RulesRepository(context).loadRules())

    fun parseAll(items: List<BomItem>): List<BomItem> =
        items.map { it.copy(spec = parser.parse(it.model)) }

    fun summarize(items: List<BomItem>): List<BomSummary> {
        val map = LinkedHashMap<String, BomSummary>()
        items.forEach { item ->
            val existing = map[item.model]
            map[item.model] = if (existing == null) {
                BomSummary(item.model, item.qty, item.refDes, item.spec)
            } else {
                existing.copy(
                    totalQty = existing.totalQty + item.qty,
                    refDes = if (existing.refDes.isBlank()) item.refDes
                    else if (item.refDes.isBlank()) existing.refDes
                    else "${existing.refDes},${item.refDes}"
                )
            }
        }
        return map.values.toList()
    }
}
