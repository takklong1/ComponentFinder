package com.example.componentfinder.bom

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

object BomExporter {

    fun exportCsv(
        context: Context,
        summary: List<BomSummary>,
        items: List<BomItem>
    ): String? {
        return try {
            val sb = StringBuilder()
            sb.append("型号,总数量,位号,封装,容值/阻值,精度,电压,材质,品牌\n")
            summary.forEach { s ->
                sb.append(
                    listOf(
                        s.model, s.totalQty.toString(), s.refDes,
                        s.spec?.packageName ?: "-", s.spec?.value ?: "-",
                        s.spec?.tolerance ?: "-", s.spec?.voltage ?: "-",
                        s.spec?.material ?: "-", s.spec?.brand ?: "-"
                    ).joinToString(",") { it.replace(",", " ") }
                ).append("\n")
            }
            sb.append("\n明细\n")
            sb.append("行号,型号,数量,位号,封装,容值/阻值,精度,电压,材质,品牌\n")
            items.forEach { i ->
                sb.append(
                    listOf(
                        i.lineNo.toString(), i.model, i.qty.toString(), i.refDes,
                        i.spec?.packageName ?: "-", i.spec?.value ?: "-",
                        i.spec?.tolerance ?: "-", i.spec?.voltage ?: "-",
                        i.spec?.material ?: "-", i.spec?.brand ?: "-"
                    ).joinToString(",") { it.replace(",", " ") }
                ).append("\n")
            }

            val file = File(context.cacheDir, "bom_export.csv")
            file.writeText(sb.toString(), Charsets.UTF_8)

            val uri = FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "导出 BOM"))
            null
        } catch (e: Exception) {
            "导出失败：${e.message}"
        }
    }
}
