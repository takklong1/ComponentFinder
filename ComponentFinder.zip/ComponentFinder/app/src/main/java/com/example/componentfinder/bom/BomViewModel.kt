package com.example.componentfinder.bom

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BomViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = BomRepository(app)

    private val _items = MutableStateFlow<List<BomItem>>(emptyList())
    val items: StateFlow<List<BomItem>> = _items

    private val _summary = MutableStateFlow<List<BomSummary>>(emptyList())
    val summary: StateFlow<List<BomSummary>> = _summary

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    fun importText(text: String) {
        viewModelScope.launch {
            _loading.value = true
            val parsed = withContext(Dispatchers.Default) {
                val raw = BomParser.parse(text)
                repo.parseAll(raw)
            }
            _items.value = parsed
            _summary.value = repo.summarize(parsed)
            _loading.value = false
        }
    }

    fun clear() {
        _items.value = emptyList()
        _summary.value = emptyList()
    }
}
