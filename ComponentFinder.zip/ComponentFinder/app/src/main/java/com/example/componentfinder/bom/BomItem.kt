package com.example.componentfinder.bom

import com.example.componentfinder.domain.model.ComponentSpec

data class BomItem(
    val lineNo: Int,
    val model: String,
    val qty: Int,
    val refDes: String = "",
    val spec: ComponentSpec? = null
)

data class BomSummary(
    val model: String,
    val totalQty: Int,
    val refDes: String,
    val spec: ComponentSpec?
)
