package com.example.componentfinder.domain.parser

import com.example.componentfinder.domain.model.ComponentSpec

object UniversalBrandParser {

    // 通用尺寸
    private val SIZES = listOf("0201","0402","0603","0805","1206","1210","1812","2010","2512","3225","4532","6432")

    // Viking 尺寸代码 → 英制封装
    private val VIKING_SIZE = mapOf(
        "01" to "0201", "02" to "0402", "03" to "0603", "05" to "0805",
        "06" to "1206", "10" to "1210", "12" to "2512", "0A" to "2010"
    )

    private val TOL = mapOf(
        "A" to "±0.05%", "B" to "±0.1%", "C" to "±0.25%",
        "D" to "±0.5%", "F" to "±1%", "G" to "±2%",
        "J" to "±5%", "K" to "±10%", "M" to "±20%"
    )

    fun parseAll(input: String): List<ComponentSpec> {
        val c = input.trim().uppercase().replace(" ", "")
        val out = mutableListOf<ComponentSpec>()
        parseViking(c)?.let { out.add(it) }
        parseGenericThickFilm(c)?.let { out.add(it) }
        return out
    }

    // ============ Viking 全系列 ============
    // CR-06JL7----0R   CR-03FA7---10R   AR03BTCX2002   RS-05K102JT
    private fun parseViking(code: String): ComponentSpec? {
        // CR/AR/RS 系列：前缀-尺寸+精度+...+阻值
        val m = Regex("^(CR|AR|RS|ARN|ARF|TAR|LR)-?(\\d{2}|0A)([A-Z])([A-Z]*)-*([0-9]+[RKM]?[0-9]*)$")
            .find(code) ?: return null
        val series = m.groupValues[1]
        val sizeCode = m.groupValues[2]
        val tolCode = m.groupValues[3]
        val rest = m.groupValues[5]

        val pkg = VIKING_SIZE[sizeCode] ?: sizeCode
        val tol = TOL[tolCode] ?: tolCode
        val value = CodeMaps.resValue(rest)

        val material = when (series) {
            "AR", "ARN", "ARF", "TAR" -> "薄膜"
            "LR" -> "合金"
            else -> "厚膜"
        }

        return ComponentSpec(
            type = "电阻",
            packageName = pkg,
            value = value,
            tolerance = tol,
            voltage = "-",
            quantity = "-",
            material = material,
            brand = "Viking (光颉) $series 系列"
        )
    }

    // ============ 通用厚膜电阻：RC1206FN330KP / AC0805K101FT ============
    // 格式：前缀(2-3字母) + 尺寸(4位数字) + 精度(1字母) + 其他代码(0-N字母) + 阻值 + 包装
    private fun parseGenericThickFilm(code: String): ComponentSpec? {
        // 先定位尺寸
        val size = SIZES.firstOrNull { code.contains(it) } ?: return null
        val sizeIdx = code.indexOf(size)
        if (sizeIdx == 0) return null
        val prefix = code.substring(0, sizeIdx)
        if (prefix.length < 2 || prefix.length > 4) return null
        // 前缀必须是字母
        if (!prefix.all { it.isLetter() }) return null

        val afterSize = code.substring(sizeIdx + size.length)
        if (afterSize.length < 3) return null

        // 紧接的第 1 个字母是精度
        val tolChar = afterSize[0]
        if (!tolChar.isLetter()) return null
        val tol = TOL[tolChar.toString()] ?: return null

        // 剩余部分提取阻值代码
        val remaining = afterSize.substring(1)
        // 阻值代码：数字[.数字][RKM][数字] 形式
        val resMatch = Regex("(\\d+[RKM]?\\d*)").find(remaining) ?: return null
        val resCode = resMatch.value
        if (resCode.isEmpty()) return null

        return ComponentSpec(
            type = "电阻",
            packageName = size,
            value = CodeMaps.resValue(resCode),
            tolerance = tol,
            voltage = "-",
            quantity = "-",
            material = "厚膜",
            brand = if (prefix == "RC") "通用 RC 系列" else "$prefix 系列"
        )
    }
}
