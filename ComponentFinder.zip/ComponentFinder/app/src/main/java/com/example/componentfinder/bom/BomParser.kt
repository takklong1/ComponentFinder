package com.example.componentfinder.bom

object BomParser {

    private val MODEL_KEYS = listOf("model", "p/n", "pn", "型号", "料号", "part", "mpn", "物料")
    private val QTY_KEYS = listOf("qty", "数量", "用量", "pcs", "count")
    private val REF_KEYS = listOf("ref", "位号", "designator", "location", "位置")

    fun parse(text: String): List<BomItem> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()

        val first = lines.first().lowercase()
        val hasHeader = MODEL_KEYS.any { first.contains(it) } ||
                QTY_KEYS.any { first.contains(it) }

        val dataLines = if (hasHeader) lines.drop(1) else lines
        val delimiter = detectDelimiter(lines.firstOrNull() ?: "")

        var modelIdx = 0
        var qtyIdx = 1
        var refIdx = -1
        if (hasHeader) {
            val cols = splitLine(lines.first(), delimiter)
            modelIdx = -1; qtyIdx = -1; refIdx = -1
            cols.forEachIndexed { i, col ->
                val c = col.lowercase().trim()
                if (modelIdx < 0 && MODEL_KEYS.any { c.contains(it) }) modelIdx = i
                else if (qtyIdx < 0 && QTY_KEYS.any { c.contains(it) }) qtyIdx = i
                else if (refIdx < 0 && REF_KEYS.any { c.contains(it) }) refIdx = i
            }
            if (modelIdx < 0) modelIdx = 0
            if (qtyIdx < 0) qtyIdx = 1
        }

        val items = mutableListOf<BomItem>()
        dataLines.forEachIndexed { index, line ->
            val cols = splitLine(line, delimiter)
            if (cols.isEmpty()) return@forEachIndexed
            val model = cols.getOrNull(modelIdx)?.trim()?.trim('"') ?: return@forEachIndexed
            if (model.isBlank()) return@forEachIndexed
            val qty = cols.getOrNull(qtyIdx)?.trim()?.trim('"')?.toIntOrNull() ?: 1
            val ref = if (refIdx >= 0) cols.getOrNull(refIdx)?.trim()?.trim('"') ?: "" else ""
            items.add(
                BomItem(
                    lineNo = index + 1,
                    model = model,
                    qty = if (qty > 0) qty else 1,
                    refDes = ref
                )
            )
        }
        return items
    }

    private fun detectDelimiter(sample: String): Char {
        val candidates = listOf(',', '\t', ';', '|')
        return candidates.maxByOrNull { c -> sample.count { it == c } } ?: ','
    }

    private fun splitLine(line: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuote = false
        for (ch in line) {
            when {
                ch == '"' -> inQuote = !inQuote
                ch == delimiter && !inQuote -> {
                    result.add(sb.toString()); sb.clear()
                }
                else -> sb.append(ch)
            }
        }
        result.add(sb.toString())
        return result
    }
}
