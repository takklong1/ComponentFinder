package com.example.componentfinder.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val model: String,
    val packageName: String,
    val value: String,
    val tolerance: String,
    val voltage: String,
    val quantity: String,
    val material: String,
    val brand: String,
    val timestamp: Long = System.currentTimeMillis()
)
