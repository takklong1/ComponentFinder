package com.example.componentfinder.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.componentfinder.ui.home.HomeScreen
import com.example.componentfinder.ui.result.ResultScreen

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(onResult = { model ->
                val encoded = java.net.URLEncoder.encode(model, "UTF-8")
                nav.navigate("result/$encoded")
            })
        }
        composable("result/{model}") { entry ->
            val model = java.net.URLDecoder.decode(
                entry.arguments?.getString("model") ?: "", "UTF-8"
            )
            ResultScreen(model = model, onBack = { nav.popBackStack() })
        }
    }
}
