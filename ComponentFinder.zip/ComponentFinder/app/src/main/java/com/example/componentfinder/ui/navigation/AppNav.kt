package com.example.componentfinder.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.componentfinder.bom.BomImportScreen
import com.example.componentfinder.bom.BomResultScreen
import com.example.componentfinder.ui.converter.UnitConverterScreen
import com.example.componentfinder.ui.history.HistoryScreen
import com.example.componentfinder.ui.home.HomeScreen
import com.example.componentfinder.ui.result.ResultScreen

@Composable
fun AppNav(startDestination: String = "home") {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = startDestination) {

        composable("home") {
            HomeScreen(
                onResult = { model ->
                    val encoded = java.net.URLEncoder.encode(model, "UTF-8")
                    nav.navigate("result/$encoded")
                },
                onBomImport = { nav.navigate("bom_import") },
                onHistory = { nav.navigate("history") },
                onConverter = { nav.navigate("converter") }
            )
        }
        composable("result/{model}") { entry ->
            val model = java.net.URLDecoder.decode(
                entry.arguments?.getString("model") ?: "", "UTF-8"
            )
            ResultScreen(model = model, onBack = { nav.popBackStack() })
        }
        composable("history") {
            HistoryScreen(onBack = { nav.popBackStack() })
        }
        composable("converter") {
            UnitConverterScreen(onBack = { nav.popBackStack() })
        }
        composable("bom_import") {
            BomImportScreen(
                onBack = { nav.popBackStack() },
                onDone = { nav.navigate("bom_result") }
            )
        }
        composable("bom_result") {
            BomResultScreen(onBack = { nav.popBackStack() })
        }
    }
}
