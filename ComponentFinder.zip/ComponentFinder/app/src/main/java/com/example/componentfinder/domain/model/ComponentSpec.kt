package com.example.componentfinder.domain.model

data class ComponentSpec(
    val type: String,
    val packageName: String,
    val value: String,
    val tolerance: String,
    val voltage: String,
    val quantity: String,
    val material: String,
    val brand: String
) {
    fun toOrderedList(): List<Pair<String, String>> = listOf(
        "封装" to packageName,
        (if (type == "电阻") "阻值" else "容值") to value,
        "精度" to tolerance,
        "电压" to voltage,
        "数量" to quantity,
        "材质" to material,
        "品牌" to brand
    )
}
