package com.example.componentfinder.data

import android.content.Context
import com.example.componentfinder.data.db.AppDatabase
import com.example.componentfinder.data.db.HistoryEntity
import com.example.componentfinder.domain.model.ComponentSpec

class HistoryRepository(context: Context) {
    private val dao = AppDatabase.get(context).historyDao()

    suspend fun save(model: String, spec: ComponentSpec) {
        dao.insert(
            HistoryEntity(
                model = model,
                packageName = spec.packageName,
                value = spec.value,
                tolerance = spec.tolerance,
                voltage = spec.voltage,
                quantity = spec.quantity,
                material = spec.material,
                brand = spec.brand
            )
        )
    }

    fun getAll() = dao.getAll()
    suspend fun clear() = dao.clearAll()
}
