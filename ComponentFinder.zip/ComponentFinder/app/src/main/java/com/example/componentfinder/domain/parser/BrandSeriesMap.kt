package com.example.componentfinder.domain.parser

object BrandSeriesMap {
    val map = mapOf(
        "YAGEO" to listOf("CC", "AC", "RC", "RL"),
        "SAMSUNG" to listOf("CL", "CK"),
        "MURATA" to listOf("GRM", "GCM", "GA2", "GA3"),
        "TDK" to listOf("C", "CGA", "CGA5"),
        "KEMET" to listOf("C", "CAS", "CBR"),
        "AVX" to listOf("VJ", "0402", "0603", "0805"),
        "VISHAY" to listOf("VJ"),
        "WALSIN" to listOf("0402", "0603", "0805", "1206"),
        "TAIYO YUDEN" to listOf("EMK", "JMK", "UMK", "TMK"),
        "FH" to listOf("0603", "0805", "1206"),
        "CCTC" to listOf("TCC"),
        "UNI-ROYAL" to listOf("0402", "0603", "0805", "1206")
    )
}
