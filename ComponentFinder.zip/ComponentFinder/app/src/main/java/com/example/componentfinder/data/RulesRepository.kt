package com.example.componentfinder.data

import android.content.Context
import com.example.componentfinder.domain.model.Rule
import org.json.JSONArray

class RulesRepository(private val context: Context) {
    fun loadRules(): List<Rule> {
        val json = context.assets.open("rules.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(json)
        val rules = mutableListOf<Rule>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            rules.add(
                Rule(
                    brand = obj.getString("brand"),
                    type = obj.getString("type"),
                    pattern = Regex(obj.getString("pattern")),
                    packageGroup = obj.optInt("packageGroup", -1),
                    valueGroup = obj.optInt("valueGroup", -1),
                    toleranceGroup = obj.optInt("toleranceGroup", -1),
                    voltageGroup = obj.optInt("voltageGroup", -1),
                    materialGroup = obj.optInt("materialGroup", -1)
                )
            )
        }
        return rules
    }
}
