package com.example.componentfinder.domain.parser

object CodeMaps {

    fun capValue(code: String): String {
        val c = code.uppercase().replace(" ", "")
        if (c == "-" || c.isEmpty()) return "-"
        if (c.matches(Regex("\\d{3}"))) {
            val base = c.substring(0, 2).toInt()
            val mult = c.substring(2).toInt()
            return formatCap(base * Math.pow(10.0, mult.toDouble()))
        }
        val m = Regex("^(\\d+)([PNU])(\\d*)$").find(c)
        if (m != null) {
            val (num, unit, extra) = m.destructured
            val base = if (extra.isNotEmpty()) "$num.$extra".toDouble() else num.toDouble()
            val pf = when (unit) {
                "P" -> base
                "N" -> base * 1000
                "U" -> base * 1_000_000
                else -> base
            }
            return formatCap(pf)
        }
        return c
    }

    private fun formatCap(pf: Double): String {
        val v = round(pf)
        return when {
            v >= 1_000_000 -> "${trim(v / 1_000_000)} µF"
            v >= 1000 -> "${trim(v / 1000)} nF"
            else -> "${trim(v)} pF"
        }
    }

    fun resValue(code: String): String {
        val c = code.uppercase().replace(" ", "")
        if (c == "-" || c.isEmpty()) return "-"
        if (c.matches(Regex("\\d{3,4}"))) {
            val digits = c.length
            val base = if (digits == 3) c.substring(0, 2).toInt() else c.substring(0, 3).toInt()
            val mult = c.last().toString().toInt()
            return formatRes(base * Math.pow(10.0, mult.toDouble()))
        }
        val m = Regex("^(\\d+)([RKM])(\\d*)$").find(c)
        if (m != null) {
            val (num, unit, extra) = m.destructured
            val base = if (extra.isNotEmpty()) "$num.$extra".toDouble() else num.toDouble()
            val ohm = when (unit) {
                "R" -> base
                "K" -> base * 1000
                "M" -> base * 1_000_000
                else -> base
            }
            return formatRes(ohm)
        }
        if (c.length > 4) {
            val trimmed = c.substring(0, 4)
            if (trimmed != c) return resValue(trimmed)
        }
        if (c == "0R" || c == "0") return "0Ω"
        return c
    }

    private fun formatRes(ohm: Double): String {
        val v = round(ohm)
        return when {
            v >= 1_000_000 -> "${trim(v / 1_000_000)} MΩ"
            v >= 1000 -> "${trim(v / 1000)} kΩ"
            else -> "${trim(v)} Ω"
        }
    }

    fun voltage(code: String): String {
        val c = code.uppercase().replace(" ", "")
        if (c == "-" || c.isEmpty()) return "-"
        return when (c) {
            "9BN", "9BB", "B8", "500", "1H", "A" -> "50V"
            "0BN", "OBN", "0BB", "OBB", "8BB", "1E", "X", "T" -> "25V"
            "7BB", "1C", "Y", "J" -> "16V"
            "5BB", "0J" -> "6.3V"
            "C8", "101", "2A", "1", "B" -> "100V"
            "2E", "251" -> "250V"
            "2J", "L" -> "630V"
            "102", "1K", "3A" -> "1000V"
            "451" -> "450V"
            "160" -> "16V"
            "250" -> "25V"
            "Z" -> "10V"
            "3" -> "25V"
            "5" -> "50V"
            "E" -> "500V"
            else -> c
        }
    }

    fun material(code: String): String {
        val c = code.uppercase().replace(" ", "")
        if (c == "-" || c.isEmpty()) return "-"
        return when {
            c.contains("NPO") || c.contains("C0G") || c.contains("CG") -> "NPO (C0G)"
            c.contains("X7R") -> "X7R"
            c.contains("X7S") -> "X7S"
            c.contains("X7T") -> "X7T"
            c.contains("X6S") -> "X6S"
            c.contains("X6T") -> "X6T"
            c.contains("X5R") -> "X5R"
            c.contains("Y5V") -> "Y5V"
            else -> c
        }
    }

    fun tolerance(code: String): String {
        val c = code.uppercase().replace(" ", "")
        if (c == "-" || c.isEmpty()) return "-"
        val key = if (c.length >= 2 && c[0] in "JKMFGBCDZ") c[0].toString() else c
        return when (key) {
            "J" -> "±5%"
            "K" -> "±10%"
            "M" -> "±20%"
            "F" -> "±1%"
            "G" -> "±2%"
            "B" -> "±0.1%"
            "C" -> "±0.25%"
            "D" -> "±0.5%"
            "Z" -> "+80%/-20%"
            else -> c
        }
    }

    private fun round(v: Double): Double = Math.round(v * 1000.0) / 1000.0

    private fun trim(v: Double): String {
        val r = round(v)
        return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
    }
}
