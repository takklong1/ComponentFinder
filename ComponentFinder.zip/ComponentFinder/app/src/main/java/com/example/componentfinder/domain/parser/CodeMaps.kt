package com.example.componentfinder.domain.parser

object CodeMaps {
    fun capValue(code: String): String {
        val c = code.uppercase().replace(" ", "")
        if (c == "-" || c.isEmpty()) return "-"
        if (c.matches(Regex("\\d{3}"))) {
            val base = c.substring(0, 2).toInt()
            val mult = c.substring(2).toInt()
            return formatCap(base * Math.pow(10.0, mult.toDouble()))
        }
        return c
    }
    private fun formatCap(pf: Double): String = when {
        pf >= 1_000_000 -> "${trim(pf / 1_000_000)} µF"
        pf >= 1000 -> "${trim(pf / 1000)} nF"
        else -> "${trim(pf)} pF"
    }
    fun resValue(code: String): String {
        val c = code.uppercase().replace(" ", "")
        if (c.matches(Regex("\\d{3,4}"))) {
            val digits = c.length
            val base = if (digits == 3) c.substring(0, 2).toInt() else c.substring(0, 3).toInt()
            val mult = c.last().toString().toInt()
            return formatRes(base * Math.pow(10.0, mult.toDouble()))
        }
        return c
    }
    private fun formatRes(ohm: Double): String = when {
        ohm >= 1_000_000 -> "${trim(ohm / 1_000_000)} MΩ"
        ohm >= 1000 -> "${trim(ohm / 1000)} kΩ"
        else -> "${trim(ohm)} Ω"
    }
    fun voltage(code: String): String = when (code.uppercase()) {
        "9BN","9BB","B8","500","1H" -> "50V"
        "0BN","OBN","0BB","OBB","8BB","1E" -> "25V"
        "7BB","1C" -> "16V"
        "5BB","0J" -> "6.3V"
        "C8","101","2A" -> "100V"
        "2E","251" -> "250V"
        "102","1K" -> "1000V"
        "451" -> "450V"
        "160" -> "16V"
        else -> "-"
    }
    fun material(code: String): String {
        val c = code.uppercase()
        return when {
            c.contains("NPO")||c.contains("C0G")||c.contains("CG") -> "NPO (C0G)"
            c.contains("X7R") -> "X7R"
            c.contains("X5R") -> "X5R"
            c.contains("Y5V") -> "Y5V"
            else -> "-"
        }
    }
    fun tolerance(code: String): String {
        val c = code.uppercase()
        val key = if (c.isNotEmpty() && c[0] in "JKMFGBCDZ") c[0].toString() else c
        return when (key) {
            "J" -> "±5%"; "K" -> "±10%"; "M" -> "±20%"
            "F" -> "±1%"; "G" -> "±2%"; "B" -> "±0.1%"
            "C" -> "±0.25%"; "D" -> "±0.5%"
            else -> "-"
        }
    }
    private fun trim(v: Double): String {
        val r = Math.round(v * 1000.0) / 1000.0
        return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
    }
}
