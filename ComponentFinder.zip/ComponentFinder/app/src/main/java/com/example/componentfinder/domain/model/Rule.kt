package com.example.componentfinder.domain.model

data class Rule(
    val brand: String,
    val type: String,
    val pattern: Regex,
    val packageGroup: Int = -1,
    val valueGroup: Int = -1,
    val toleranceGroup: Int = -1,
    val voltageGroup: Int = -1,
    val materialGroup: Int = -1
)
