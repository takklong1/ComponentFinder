package com.example.componentfinder.camera

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.componentfinder.ui.theme.ComponentFinderTheme
import com.example.componentfinder.util.ModelExtractor
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CameraScanActivity : ComponentActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val EXTRA_RESULT = "result"
        const val MODE_BARCODE = "barcode"
        const val MODE_OCR = "ocr"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_BARCODE

        setContent {
            ComponentFinderTheme {
                ScanScreen(mode = mode) { result ->
                    val data = Intent().apply {
                        putExtra(EXTRA_RESULT, result)
                        putExtra(EXTRA_MODE, mode)
                    }
                    setResult(RESULT_OK, data)
                    finish()
                }
            }
        }
    }
}

@Composable
fun ScanScreen(mode: String, onResult: (String) -> Unit) {
    val context = LocalContext.current
    val analyzerMode = if (mode == CameraScanActivity.MODE_OCR)
        AnalyzerMode.OCR else AnalyzerMode.BARCODE
    var rawText by remember { mutableStateOf<String?>(null) }
    var candidates by remember { mutableStateOf<List<String>>(emptyList()) }
    var editing by remember { mutableStateOf(false) }
    var editedText by remember { mutableStateOf("") }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            processLocalImage(context, uri, analyzerMode) { result ->
                if (result.isNotBlank()) {
                    rawText = result
                } else {
                    Toast.makeText(context, "未识别到内容", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    LaunchedEffect(rawText) {
        rawText?.let {
            candidates = ModelExtractor.extractAll(it)
            editedText = candidates.firstOrNull() ?: it
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        CameraPreview(
            analyzerMode = analyzerMode,
            onCodeDetected = { text ->
                if (rawText == null && text.isNotBlank()) {
                    rawText = text
                }
            }
        )

        Text(
            text = if (analyzerMode == AnalyzerMode.BARCODE)
                "对准条码/二维码" else "对准标签文字",
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 48.dp),
            color = MaterialTheme.colorScheme.onPrimary
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            Button(
                onClick = { imagePicker.launch("image/*") },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary
                )
            ) {
                Text("从相册选择图片")
            }
        }

        if (rawText != null) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(bottom = 80.dp, start = 16.dp, end = 16.dp),
                tonalElevation = 6.dp
            ) {
                Column(
                    Modifier.padding(16.dp).verticalScroll(rememberScrollState())
                ) {
                    Text("原始识别：", style = MaterialTheme.typography.labelSmall)
                    Text(rawText!!, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))

                    if (candidates.isNotEmpty()) {
                        Text("候选型号：", style = MaterialTheme.typography.labelSmall)
                        candidates.forEach { c ->
                            OutlinedButton(
                                onClick = { onResult(c) },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                            ) { Text(c) }
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    if (editing) {
                        OutlinedTextField(
                            value = editedText,
                            onValueChange = { editedText = it },
                            label = { Text("手动修正") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { onResult(editedText) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("用修正后的查询") }
                    } else {
                        OutlinedButton(
                            onClick = { editing = true },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("手动修正") }
                    }

                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        OutlinedButton(onClick = {
                            rawText = null
                            candidates = emptyList()
                            editing = false
                        }) { Text("重扫") }
                    }
                }
            }
        }
    }
}

private fun processLocalImage(
    context: Context,
    uri: Uri,
    mode: AnalyzerMode,
    onResult: (String) -> Unit
) {
    val image = try {
        InputImage.fromFilePath(context, uri)
    } catch (e: Exception) {
        e.printStackTrace()
        onResult("")
        return
    }

    if (mode == AnalyzerMode.BARCODE) {
        val scanner = BarcodeScanning.getClient()
        scanner.process(image)
            .addOnSuccessListener { barcodes ->
                val result = barcodes.firstOrNull { it.rawValue != null }?.rawValue
                onResult(result ?: "")
            }
            .addOnFailureListener { onResult("") }
    } else {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                onResult(visionText.text)
            }
            .addOnFailureListener { onResult("") }
    }
}
