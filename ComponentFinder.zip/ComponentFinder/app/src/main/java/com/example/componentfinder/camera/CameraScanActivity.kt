package com.example.componentfinder.camera

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.componentfinder.ui.theme.ComponentFinderTheme

class CameraScanActivity : ComponentActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val EXTRA_RESULT = "result"
        const val MODE_BARCODE = "barcode"
        const val MODE_OCR = "ocr"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_BARCODE

        setContent {
            ComponentFinderTheme {
                ScanScreen(mode = mode) { result ->
                    val data = Intent().apply {
                        putExtra(EXTRA_RESULT, result)
                        putExtra(EXTRA_MODE, mode)
                    }
                    setResult(RESULT_OK, data)
                    finish()
                }
            }
        }
    }
}

@Composable
fun ScanScreen(mode: String, onResult: (String) -> Unit) {
    val analyzerMode = if (mode == CameraScanActivity.MODE_OCR)
        AnalyzerMode.OCR else AnalyzerMode.BARCODE
    var lastResult by remember { mutableStateOf<String?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        CameraPreview(
            analyzerMode = analyzerMode,
            onCodeDetected = { text ->
                if (lastResult == null && text.isNotBlank()) {
                    lastResult = text
                }
            }
        )

        Text(
            text = if (analyzerMode == AnalyzerMode.BARCODE)
                "对准条码/二维码" else "对准标签文字",
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 48.dp),
            color = MaterialTheme.colorScheme.onPrimary
        )

        lastResult?.let { result ->
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp),
                tonalElevation = 6.dp
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("识别到：", style = MaterialTheme.typography.labelSmall)
                    Text(result, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        OutlinedButton(onClick = { lastResult = null }) { Text("重扫") }
                        Button(onClick = { onResult(result) }) { Text("使用") }
                    }
                }
            }
        }
    }
}
