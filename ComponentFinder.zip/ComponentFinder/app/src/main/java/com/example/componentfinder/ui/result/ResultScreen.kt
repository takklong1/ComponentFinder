package com.example.componentfinder.ui.result

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.componentfinder.data.HistoryRepository
import com.example.componentfinder.data.RulesRepository
import com.example.componentfinder.domain.parser.ParserEngine

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(model: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val rules = remember { RulesRepository(context).loadRules() }
    val parser = remember { ParserEngine(rules) }
    val spec = remember(model) { parser.parse(model) }
    val historyRepo = remember { HistoryRepository(context) }

    LaunchedEffect(spec) {
        if (spec != null) historyRepo.save(model, spec)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("解析结果") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (spec == null) {
                Text("未识别该型号，请补充规则库")
            } else {
                Text("型号：$model", style = MaterialTheme.typography.titleSmall)
                HorizontalDivider()
                spec.toOrderedList().forEach { (k, v) ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(k, style = MaterialTheme.typography.bodyLarge)
                        Text(v, style = MaterialTheme.typography.bodyLarge)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
