package com.example.componentfinder.ui.result

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.componentfinder.data.RulesRepository
import com.example.componentfinder.domain.parser.ParserEngine

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(model: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val rules = remember { RulesRepository(context).loadRules() }
    val parser = remember { ParserEngine(rules) }
    val specs = remember(model) { parser.parseAll(model) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("解析结果") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("原始输入：$model", style = MaterialTheme.typography.bodySmall)
            HorizontalDivider()

            if (specs.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFCDD2)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("❌ 未识别", style = MaterialTheme.typography.titleMedium)
                        Text("版本 v2.0 - 如果你看到这行，说明代码是最新的",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                Text("共找到 ${specs.size} 个结果：",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary)
                specs.forEachIndexed { idx, spec ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("【${spec.type}】候选 ${idx + 1}",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(8.dp))
                            spec.toOrderedList().forEach { (k, v) ->
                                if (v != "-" && v.isNotEmpty()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(k, style = MaterialTheme.typography.bodyMedium)
                                        Text(v, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
