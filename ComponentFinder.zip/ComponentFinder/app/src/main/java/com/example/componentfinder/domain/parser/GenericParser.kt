package com.example.componentfinder.domain.parser

import com.example.componentfinder.domain.model.ComponentSpec

object GenericParser {
    fun parse(input: String): ComponentSpec? = null
}
