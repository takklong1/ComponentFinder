package com.example.componentfinder.domain.parser

import com.example.componentfinder.domain.model.ComponentSpec

/**
 * 通用解析器：当所有品牌规则都不匹配时使用
 * 通过扫描文本中的封装、材质、容值/阻值代码、精度、电压等特征进行解析
 */
object GenericParser {

    private val PACKAGE_LIST = listOf(
        "0402", "0603", "0805", "1206", "1210", "1812", "2012", "3216", "1005", "1608"
    )

    fun parse(input: String): ComponentSpec? {
        val c = input.uppercase().replace(" ", "").replace("-", "")
            .replace("\n", "").replace("\t", "")

        // 提取封装
        val pkg = PACKAGE_LIST.firstOrNull { c.contains(it) } ?: return null

        // 提取材质
        val mat = when {
            c.contains("NPO") || c.contains("C0G") -> "NPO (C0G)"
            c.contains("X7R") -> "X7R"
            c.contains("X7S") -> "X7S"
            c.contains("X6S") -> "X6S"
            c.contains("X5R") -> "X5R"
            c.contains("Y5V") -> "Y5V"
            c.contains("CG") -> "NPO (C0G)"
            else -> "-"
        }

        // 判断电阻还是电容
        // 电阻标志：有R前缀、或在型号中包含R+数字
        val isResistor = c.contains("RC") ||
                (c.startsWith("R") && c.length > 1 && c[1].isDigit()) ||
                (c.contains("R") && !c.contains("NPO") && !c.contains("X7R") &&
                        !c.contains("X5R") && !c.contains("X7S") && !c.contains("C0G"))

        // 提取所有3-4位数字代码（排除封装本身）
        val allDigits = Regex("\\d{3,4}").findAll(c).map { it.value }.toList()
        val valueCodes = allDigits.filter { it != pkg }

        // 提取容值/阻值
        val value = if (valueCodes.isEmpty()) {
            "-"
        } else {
            if (isResistor) CodeMaps.resValue(valueCodes.last())
            else CodeMaps.capValue(valueCodes.last())
        }

        // 提取精度：在数字代码后紧跟的 J/K/M/F
        val tolMatch = Regex("\\d{3,4}([JKMF])").find(c)
        val tol = tolMatch?.groupValues?.get(1) ?: "-"

        // 提取电压：3位数字代码，如 500=50V, 101=100V, 251=250V
        val voltMatch = Regex("\\d{3}").findAll(c)
            .map { it.value }
            .filter { it != pkg && it !in valueCodes.take(valueCodes.size - 1) }
            .lastOrNull { it.length == 3 && it.toIntOrNull() != null && it.toInt() in 100..102 }
        val volt = voltMatch?.let { CodeMaps.voltage(it) } ?: "-"

        return ComponentSpec(
            type = if (isResistor) "电阻" else "电容",
            packageName = pkg,
            value = value,
            tolerance = CodeMaps.tolerance(tol),
            voltage = volt,
            quantity = "-",
            material = mat,
            brand = "通用"
        )
    }
}
