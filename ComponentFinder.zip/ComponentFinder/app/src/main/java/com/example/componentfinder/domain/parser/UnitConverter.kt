package com.example.componentfinder.domain.parser

object UnitConverter {
    fun pfToNf(pf: Double) = pf / 1000
    fun nfToUf(nf: Double) = nf / 1000
    fun ufToNf(uf: Double) = uf * 1000
    fun nfToPf(nf: Double) = nf * 1000
    fun ohmToKohm(ohm: Double) = ohm / 1000
    fun kohmToMohm(kohm: Double) = kohm / 1000
}
