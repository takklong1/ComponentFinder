package com.example.componentfinder.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onResult: (String) -> Unit) {
    var input by remember { mutableStateOf("") }

    Scaffold(topBar = { TopAppBar(title = { Text("元件快查 v2.0") }) }) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 醒目的版本号横幅
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1976D2)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text("🎉 版本 v2.0", color = Color.White,
                        style = MaterialTheme.typography.titleMedium)
                    Text("如果你看到这行字，说明装的是最新版",
                        color = Color.White, style = MaterialTheme.typography.bodySmall)
                }
            }

            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("输入型号 / 丝印（如 104、1001、01B）") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { if (input.isNotBlank()) onResult(input) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("查询") }

            // 一键测试
            Button(
                onClick = { onResult("104") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
            ) { Text("🧪 一键测试：查询 104") }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("💡 应该看到什么？", style = MaterialTheme.typography.titleSmall)
                    Text("• 104 → 电容 100nF + 电阻 100kΩ", style = MaterialTheme.typography.bodySmall)
                    Text("• 1001 → 电阻 1kΩ (±1%)", style = MaterialTheme.typography.bodySmall)
                    Text("• 01B → 电阻 1kΩ (±1%, 0603)", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
