package com.example.componentfinder.ui.home

import android.app.Activity
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.componentfinder.camera.CameraScanActivity
import com.example.componentfinder.util.rememberCameraPermissionState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onResult: (String) -> Unit,
    onBomImport: () -> Unit = {},
    onHistory: () -> Unit = {},
    onConverter: () -> Unit = {}
) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    val (hasPermission, requestPermission) = rememberCameraPermissionState()

    val scanLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data?.getStringExtra(CameraScanActivity.EXTRA_RESULT)
            if (!text.isNullOrBlank()) {
                // 直接自动查询
                onResult(text)
            }
        }
    }

    fun launchScan(mode: String) {
        if (!hasPermission) { requestPermission(); return }
        val intent = Intent(context, CameraScanActivity::class.java).apply {
            putExtra(CameraScanActivity.EXTRA_MODE, mode)
        }
        scanLauncher.launch(intent)
    }

    Scaffold(topBar = { TopAppBar(title = { Text("元件快查") }) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("输入型号 / 丝印") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { if (input.isNotBlank()) onResult(input) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("查询") }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { launchScan(CameraScanActivity.MODE_BARCODE) },
                    modifier = Modifier.weight(1f)
                ) { Text("扫码") }
                OutlinedButton(
                    onClick = { launchScan(CameraScanActivity.MODE_OCR) },
                    modifier = Modifier.weight(1f)
                ) { Text("拍照识别") }
            }

            HorizontalDivider()

            OutlinedButton(
                onClick = onBomImport,
                modifier = Modifier.fillMaxWidth()
            ) { Text("导入 BOM") }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = onHistory, modifier = Modifier.weight(1f)) { Text("历史记录") }
                OutlinedButton(onClick = onConverter, modifier = Modifier.weight(1f)) { Text("单位换算") }
            }

            Text("示例：CC0603JRNPO9BN200 / 103 / 100nF", style = MaterialTheme.typography.bodySmall)
        }
    }
}
