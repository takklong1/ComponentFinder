package com.example.componentfinder.ui.home

import android.app.Activity
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.componentfinder.camera.CameraScanActivity
import com.example.componentfinder.util.rememberCameraPermissionState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onResult: (String) -> Unit) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    val (hasPermission, requestPermission) = rememberCameraPermissionState()

    val scanLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data?.getStringExtra(CameraScanActivity.EXTRA_RESULT)
            if (!text.isNullOrBlank()) {
                onResult(text)
            }
        }
    }

    fun launchScan(mode: String) {
        if (!hasPermission) {
            requestPermission()
            return
        }
        val intent = Intent(context, CameraScanActivity::class.java).apply {
            putExtra(CameraScanActivity.EXTRA_MODE, mode)
        }
        scanLauncher.launch(intent)
    }

    Scaffold(topBar = { TopAppBar(title = { Text("元件快查 v2.0") }) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding).padding(16.dp).fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1976D2)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text("🎉 版本 v2.0", color = Color.White,
                        style = MaterialTheme.typography.titleMedium)
                    Text("如果看到这行字，说明装的是最新版",
                        color = Color.White, style = MaterialTheme.typography.bodySmall)
                }
            }

            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("输入型号 / 丝印（如 104、1001、01B）") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { if (input.isNotBlank()) onResult(input) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("查询") }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { launchScan(CameraScanActivity.MODE_BARCODE) },
                    modifier = Modifier.weight(1f)
                ) { Text("📷 扫码") }
                OutlinedButton(
                    onClick = { launchScan(CameraScanActivity.MODE_OCR) },
                    modifier = Modifier.weight(1f)
                ) { Text("📝 拍照识别") }
            }

            Button(
                onClick = { onResult("104") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
            ) { Text("🧪 一键测试：查询 104") }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("💡 使用示例", style = MaterialTheme.typography.titleSmall)
                    Text("• 104 → 电容 100nF + 电阻 100kΩ", style = MaterialTheme.typography.bodySmall)
                    Text("• 1001 → 电阻 1kΩ (±1%)", style = MaterialTheme.typography.bodySmall)
                    Text("• 01B → 电阻 1kΩ (±1%, 0603)", style = MaterialTheme.typography.bodySmall)
                    Text("• 扫码/拍照：对准标签自动识别", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
