package com.example.componentfinder.domain.parser

import com.example.componentfinder.domain.model.ComponentSpec
import com.example.componentfinder.domain.model.Rule

class ParserEngine(private val rules: List<Rule>) {

    fun parseAll(input: String): List<ComponentSpec> {
        val clean = input.trim().uppercase().replace(" ", "").replace("\n", "").replace("\t", "")
        val results = LinkedHashSet<ComponentSpec>()

        for (rule in rules) {
            rule.pattern.matchEntire(clean)?.let { results.add(buildSpec(rule, it)) }
        }
        if (results.isNotEmpty()) return results.toList()

        for (candidate in extractCandidates(clean)) {
            for (rule in rules) {
                rule.pattern.matchEntire(candidate)?.let { results.add(buildSpec(rule, it)) }
            }
        }
        if (results.isNotEmpty()) return results.toList()

        SMDCodeParser.parseAll(clean).forEach { results.add(it) }
        return results.toList()
    }

    fun parse(input: String): ComponentSpec? = parseAll(input).firstOrNull()

    private fun buildSpec(rule: Rule, match: MatchResult): ComponentSpec {
        val rawValue = group(match, rule.valueGroup)
        val rawTol = group(match, rule.toleranceGroup)
        val rawVolt = group(match, rule.voltageGroup)
        val rawMat = group(match, rule.materialGroup)
        return ComponentSpec(
            type = rule.type,
            packageName = group(match, rule.packageGroup),
            value = if (rule.type == "电阻") CodeMaps.resValue(rawValue) else CodeMaps.capValue(rawValue),
            tolerance = CodeMaps.tolerance(rawTol),
            voltage = CodeMaps.voltage(rawVolt),
            quantity = "-",
            material = CodeMaps.material(rawMat),
            brand = rule.brand
        )
    }

    private fun group(match: MatchResult, index: Int): String {
        if (index <= 0) return "-"
        return match.groupValues.getOrNull(index)?.ifEmpty { "-" } ?: "-"
    }

    private fun extractCandidates(text: String): List<String> {
        val result = mutableListOf<String>()
        Regex("CC\\d{4}[A-Z]{2}(?:NPO|X7R|X5R)[0-9A-Z]{3}\\d{3}").findAll(text).forEach { result.add(it.value) }
        Regex("RC\\d{4}[A-Z]{2}-?\\d{2}[0-9A-Z]{3,4}").findAll(text).forEach { result.add(it.value) }
        Regex("CL\\d{2}[A-Z]\\d{3}[A-Z][0-9A-Z]{2}[A-Z]{3}").findAll(text).forEach { result.add(it.value) }
        Regex("TCC\\d{4}(?:X7R|X5R|NPO|C0G)\\d{3}[A-Z]\\d{3}[A-Z]{2}").findAll(text).forEach { result.add(it.value) }
        return result
    }
}
