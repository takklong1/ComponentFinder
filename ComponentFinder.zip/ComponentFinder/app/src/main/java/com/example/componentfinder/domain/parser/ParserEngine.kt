package com.example.componentfinder.domain.parser

import com.example.componentfinder.domain.model.ComponentSpec
import com.example.componentfinder.domain.model.Rule

class ParserEngine(private val rules: List<Rule>) {

    fun parseAll(input: String): List<ComponentSpec> {
        val clean = input.trim().uppercase().replace(" ", "").replace("\n", "").replace("\t", "")
        val results = LinkedHashSet<ComponentSpec>()

        // 1. rules.json 品牌规则
        for (rule in rules) {
            rule.pattern.matchEntire(clean)?.let { results.add(buildSpec(rule, it)) }
        }
        if (results.isNotEmpty()) return results.toList()

        // 2. 通用品牌解析（Viking / RC 系列）
        UniversalBrandParser.parseAll(clean).forEach { results.add(it) }
        if (results.isNotEmpty()) return results.toList()

        // 3. 丝印代码
        SMDCodeParser.parseAll(clean).forEach { results.add(it) }
        if (results.isNotEmpty()) return results.toList()

        // 4. 自然语言描述（中文/英文）
        DescriptionParser.parse(input).forEach { results.add(it) }

        return results.toList()
    }

    fun parse(input: String): ComponentSpec? = parseAll(input).firstOrNull()

    private fun buildSpec(rule: Rule, match: MatchResult): ComponentSpec {
        val rawValue = group(match, rule.valueGroup)
        val rawTol = group(match, rule.toleranceGroup)
        val rawVolt = group(match, rule.voltageGroup)
        val rawMat = group(match, rule.materialGroup)
        return ComponentSpec(
            type = rule.type,
            packageName = group(match, rule.packageGroup),
            value = if (rule.type == "电阻") CodeMaps.resValue(rawValue) else CodeMaps.capValue(rawValue),
            tolerance = CodeMaps.tolerance(rawTol),
            voltage = CodeMaps.voltage(rawVolt),
            quantity = "-",
            material = CodeMaps.material(rawMat),
            brand = rule.brand
        )
    }

    private fun group(match: MatchResult, index: Int): String {
        if (index <= 0) return "-"
        return match.groupValues.getOrNull(index)?.ifEmpty { "-" } ?: "-"
    }
}
