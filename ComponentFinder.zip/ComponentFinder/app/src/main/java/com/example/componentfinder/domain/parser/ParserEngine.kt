package com.example.componentfinder.domain.parser

import com.example.componentfinder.domain.model.ComponentSpec
import com.example.componentfinder.domain.model.Rule

class ParserEngine(private val rules: List<Rule>) {

    fun parse(input: String): ComponentSpec? {
        val clean = input.trim().uppercase()
            .replace(" ", "").replace("\n", "").replace("\t", "")

        // 1. 完整匹配
        for (rule in rules) {
            val match = rule.pattern.matchEntire(clean) ?: continue
            return buildSpec(rule, match)
        }

        // 2. 从文本中提取候选型号，逐个尝试
        val candidates = extractCandidates(clean)
        for (candidate in candidates) {
            for (rule in rules) {
                val match = rule.pattern.matchEntire(candidate) ?: continue
                return buildSpec(rule, match)
            }
        }

        // 3. 通用解析（兜底）
        return GenericParser.parse(clean)
    }

    private fun buildSpec(rule: Rule, match: MatchResult): ComponentSpec {
        val rawValue = group(match, rule.valueGroup)
        val rawTol = group(match, rule.toleranceGroup)
        val rawVolt = group(match, rule.voltageGroup)
        val rawMat = group(match, rule.materialGroup)

        return ComponentSpec(
            type = rule.type,
            packageName = group(match, rule.packageGroup),
            value = if (rule.type == "电阻") CodeMaps.resValue(rawValue) else CodeMaps.capValue(rawValue),
            tolerance = CodeMaps.tolerance(rawTol),
            voltage = CodeMaps.voltage(rawVolt),
            quantity = "-",
            material = CodeMaps.material(rawMat),
            brand = rule.brand
        )
    }

    private fun group(match: MatchResult, index: Int): String {
        if (index <= 0) return "-"
        return match.groupValues.getOrNull(index)?.ifEmpty { "-" } ?: "-"
    }

    private fun extractCandidates(text: String): List<String> {
        val result = mutableListOf<String>()
        // YAGEO 电容
        Regex("CC\\d{4}[A-Z]{2}(?:NPO|X7R|X5R)[0-9A-Z]{3}\\d{3}").findAll(text).forEach { result.add(it.value) }
        // YAGEO 电阻
        Regex("RC\\d{4}[A-Z]{2}-?\\d{2}[0-9A-Z]{3,4}").findAll(text).forEach { result.add(it.value) }
        // Samsung
        Regex("CL\\d{2}[A-Z]\\d{3}[A-Z][0-9A-Z]{2}[A-Z]{3}").findAll(text).forEach { result.add(it.value) }
        // CCTC
        Regex("TCC\\d{4}(?:X7R|X5R|NPO|C0G)\\d{3}[A-Z]\\d{3}[A-Z]{2}").findAll(text).forEach { result.add(it.value) }
        // Murata
        Regex("GRM\\d{2}[A-Z0-9]{3}[0-9A-Z]{2}\\d{3}[A-Z][A-Z0-9]{2}[A-Z0-9]").findAll(text).forEach { result.add(it.value) }
        // TDK
        Regex("C\\d{4}(?:X7R|X5R|C0G|NPO|Y5V|X7S)[0-9A-Z]{2}\\d{3}[A-Z][A-Z0-9]{3}").findAll(text).forEach { result.add(it.value) }
        // FH / Walsin 通用
        Regex("\\d{4}[A-Z]{1,2}\\d{3}[A-Z]\\d{3}[A-Z]{2}").findAll(text).forEach { result.add(it.value) }
        // UNI-ROYAL 电阻
        Regex("\\d{4}[A-Z]\\d[A-Z]\\d{4}[A-Z0-9]+").findAll(text).forEach { result.add(it.value) }
        return result
    }
}
