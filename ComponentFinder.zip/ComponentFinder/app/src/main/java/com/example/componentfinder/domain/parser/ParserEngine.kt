package com.example.componentfinder.domain.parser

import com.example.componentfinder.domain.model.ComponentSpec
import com.example.componentfinder.domain.model.Rule

class ParserEngine(private val rules: List<Rule>) {

    fun parse(input: String): ComponentSpec? {
        val clean = input.trim().uppercase().replace(" ", "")
        for (rule in rules) {
            val match = rule.pattern.matchEntire(clean) ?: continue

            val rawValue = group(match, rule.valueGroup)
            val rawTol = group(match, rule.toleranceGroup)
            val rawVolt = group(match, rule.voltageGroup)
            val rawMat = group(match, rule.materialGroup)

            return ComponentSpec(
                type = rule.type,
                packageName = group(match, rule.packageGroup),
                value = if (rule.type == "电阻") CodeMaps.resValue(rawValue) else CodeMaps.capValue(rawValue),
                tolerance = CodeMaps.tolerance(rawTol),
                voltage = CodeMaps.voltage(rawVolt),
                quantity = "-",
                material = CodeMaps.material(rawMat),
                brand = rule.brand
            )
        }
        return null
    }

    private fun group(match: MatchResult, index: Int): String {
        if (index <= 0) return "-"
        return match.groupValues.getOrNull(index)?.ifEmpty { "-" } ?: "-"
    }
}
