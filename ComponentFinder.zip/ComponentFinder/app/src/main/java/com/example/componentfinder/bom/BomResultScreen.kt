package com.example.componentfinder.bom

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BomResultScreen(
    onBack: () -> Unit,
    vm: BomViewModel = viewModel()
) {
    val context = LocalContext.current
    val summary by vm.summary.collectAsState()
    var showSummary by remember { mutableStateOf(true) }
    val items by vm.items.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (showSummary) "汇总 (${summary.size})" else "明细 (${items.size})") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } },
                actions = {
                    TextButton(onClick = { showSummary = !showSummary }) {
                        Text(if (showSummary) "明细" else "汇总")
                    }
                    TextButton(onClick = {
                        BomExporter.exportCsv(context, summary, items)
                    }) { Text("导出") }
                }
            )
        }
    ) { padding ->
        if (showSummary) {
            LazyColumn(
                modifier = Modifier.padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(summary) { s ->
                    BomCard(s.model, s.totalQty, s.refDes, s.spec)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(items) { item ->
                    BomCard("#${item.lineNo}  ${item.model}", item.qty, item.refDes, item.spec)
                }
            }
        }
    }
}

@Composable
private fun BomCard(
    title: String,
    qty: Int,
    refDes: String,
    spec: com.example.componentfinder.domain.model.ComponentSpec?
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text("数量：$qty" + if (refDes.isNotBlank()) "  位号：$refDes" else "",
                style = MaterialTheme.typography.bodySmall)
            if (spec == null) {
                Text("⚠ 未识别该型号", color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall)
            } else {
                spec.toOrderedList().forEach { (k, v) ->
                    Text("$k：$v", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
