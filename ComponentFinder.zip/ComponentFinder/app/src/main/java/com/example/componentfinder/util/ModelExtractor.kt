package com.example.componentfinder.util

object ModelExtractor {

    private val fullModelPatterns = listOf(
        Regex("CC\\d{4}[A-Z]{2}(?:NPO|X7R|X5R)[0-9A-Z]{3}\\d{3}"),
        Regex("RC\\d{4}[A-Z]{2}-?\\d{2}[0-9A-Z]{3,4}"),
        Regex("CL\\d{2}[A-Z]\\d{3}[A-Z][0-9A-Z]{2}[A-Z]{3}"),
        Regex("TCC\\d{4}(?:X7R|X5R|NPO|C0G)\\d{3}[A-Z]\\d{3}[A-Z]{2}"),
        Regex("GRM\\d{2}[A-Z0-9]{3}[0-9A-Z]{2}\\d{3}[A-Z][A-Z0-9]{2}[A-Z0-9]"),
        Regex("C\\d{4}(?:X7R|X5R|C0G|NPO|Y5V|X7S)[0-9A-Z]{2}\\d{3}[A-Z][A-Z0-9]{3}"),
        Regex("\\d{4}[A-Z]{1,2}\\d{3}[A-Z]\\d{3}[A-Z]{2}"),
        Regex("\\d{4}[A-Z]\\d[A-Z]\\d{4}[A-Z0-9]+")
    )

    fun extractAll(text: String): List<String> {
        val candidates = LinkedHashSet<String>()
        val upper = text.uppercase()

        val lines = upper.split(Regex("[\\r\\n]+"))
        for (line in lines) {
            val compact = line.replace(" ", "")
            for (p in fullModelPatterns) {
                p.find(compact)?.let { candidates.add(it.value) }
            }
        }

        if (candidates.isEmpty()) {
            val compact = upper.replace(" ", "").replace("\n", "").replace("\t", "")
            for (p in fullModelPatterns) {
                p.findAll(compact).forEach { candidates.add(it.value) }
            }
        }

        if (candidates.isEmpty()) {
            for (line in lines) {
                val compact = line.replace(" ", "").trim()
                if (compact.length in 3..5) {
                    if (compact.matches(Regex("^\\d{3,4}$")) ||
                        compact.matches(Regex("^\\d{2}[A-Z]$")) ||
                        compact.matches(Regex("^\\d+[Rr]\\d+$"))) {
                        candidates.add(compact)
                    }
                }
            }
        }

        return candidates.toList()
    }

    fun extract(text: String): String? = extractAll(text).firstOrNull()
}
