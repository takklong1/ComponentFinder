package com.example.componentfinder.util

object ModelExtractor {

    // 完整型号正则（按优先级排列）
    private val fullModelPatterns = listOf(
        // YAGEO 电容 CC0603JRNPO9BN200
        Regex("CC\\d{4}[A-Z]{2}(?:NPO|X7R|X5R|X7S)[0-9A-Z]{3}\\d{3}"),
        // YAGEO 电阻 RC0603FR-07604KL
        Regex("RC\\d{4}[A-Z]{2}-?\\d{2}[0-9A-Z]{3,4}"),
        // Samsung CL10B104KB8NFNC
        Regex("CL\\d{2}[A-Z]\\d{3}[A-Z][0-9A-Z]{2}[A-Z]{3}"),
        // CCTC TCC0603X7R104K500DT
        Regex("TCC\\d{4}(?:X7R|X5R|NPO|C0G|X7S)\\d{3}[A-Z]\\d{3}[A-Z]{2}"),
        // Murata GRM31CR61A107MEA8L
        Regex("GRM\\d{2}[A-Z0-9]{3}[0-9A-Z]{2}\\d{3}[A-Z][A-Z0-9]{2}[A-Z0-9]"),
        // TDK C3216X7R1H475K
        Regex("C\\d{4}(?:X7R|X5R|C0G|NPO|Y5V|X7S)[0-9A-Z]{2}\\d{3}[A-Z][A-Z0-9]{2,3}"),
        // FH 风华 0603B104K500NT
        Regex("\\d{4}[A-Z]{1,2}\\d{3}[A-Z]\\d{3}[A-Z]{2}"),
        // UNI-ROYAL 电阻
        Regex("\\d{4}[A-Z]\\d[A-Z]\\d{4}[A-Z0-9]+")
    )

    // 干扰词，包含这些的行不提取丝印代码
    private val noiseWords = listOf(
        "QTY", "LOT", "ROHS", "DATE", "CODE", "PCS", "INSP",
        "QUANTITY", "TOTAL", "SUBTOTAL", "PAGE", "BATCH"
    )

    fun extractAll(text: String): List<String> {
        val candidates = LinkedHashSet<String>()
        val upper = text.uppercase()

        // 1. 按行拆分
        val lines = upper.split(Regex("[\\r\\n]+"))

        // 2. 优先提取完整型号
        for (line in lines) {
            val compact = line.replace(" ", "")
            for (p in fullModelPatterns) {
                p.find(compact)?.let { candidates.add(it.value) }
            }
        }

        // 3. 整段文本再扫一遍（应对换行导致的分割）
        if (candidates.isEmpty()) {
            val compact = upper.replace(" ", "").replace("\n", "").replace("\t", "")
            for (p in fullModelPatterns) {
                p.findAll(compact).forEach { candidates.add(it.value) }
            }
        }

        // 4. 兜底：短行且无干扰词时，提取丝印代码
        if (candidates.isEmpty()) {
            for (line in lines) {
                val trimmed = line.trim()
                if (noiseWords.any { trimmed.contains(it) }) continue
                val compact = trimmed.replace(" ", "")
                // 3-4位纯数字 / 2位数字+字母 / 带R小数
                if (compact.length in 3..5 &&
                    (compact.matches(Regex("^\\d{3,4}$")) ||
                     compact.matches(Regex("^\\d{2}[A-Z]$")) ||
                     compact.matches(Regex("^\\d+[Rr]\\d+$")))) {
                    candidates.add(compact)
                }
            }
        }

        return candidates.toList()
    }

    fun extract(text: String): String? = extractAll(text).firstOrNull()
}
