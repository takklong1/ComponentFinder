package com.example.componentfinder.util

object ModelExtractor {

    private val patterns = listOf(
        // YAGEO/Samsung/CCTC/FH 等完整型号
        Regex("CC\\d{4}[A-Z]{2}(?:NPO|X7R|X5R|X7S)[0-9A-Z]{3}\\d{3}"),
        Regex("RC\\d{4}[A-Z]{2,4}-?\\d{0,2}[0-9A-Z]{3,4}[A-Z]?"),
        Regex("CL\\d{2}[A-Z]\\d{3}[A-Z][0-9A-Z]{2}[A-Z]{3}"),
        Regex("TCC\\d{4}(?:X7R|X5R|NPO|C0G|X7S)\\d{3}[A-Z]\\d{3}[A-Z]{2}"),
        Regex("GRM\\d{2}[A-Z0-9]{3}[0-9A-Z]{2}\\d{3}[A-Z][A-Z0-9]{2}[A-Z0-9]"),
        Regex("C\\d{4}(?:X7R|X5R|C0G|NPO|Y5V|X7S)[0-9A-Z]{2}\\d{3}[A-Z][A-Z0-9]{2,3}"),
        // Viking CR/AR/RS 系列
        Regex("(?:CR|AR|RS|ARN|ARF)-?\\d{2}[A-Z]+[A-Z0-9\\-]*[0-9]+[RKM]?[0-9]*"),
        // 通用厚膜
        Regex("[A-Z]{2,3}\\d{4}[A-Z][A-Z0-9]{2,8}"),
        // FH 风华
        Regex("\\d{4}[A-Z]{1,2}\\d{3}[A-Z]\\d{3}[A-Z]{2}")
    )

    private val noiseWords = listOf("QTY","LOT","ROHS","DATE","CODE","PCS","INSP","TOTAL")

    fun extractAll(text: String): List<String> {
        val candidates = LinkedHashSet<String>()
        val upper = text.uppercase()
        val lines = upper.split(Regex("[\\r\\n]+"))

        for (line in lines) {
            val compact = line.replace(" ", "")
            for (p in patterns) p.find(compact)?.let { candidates.add(it.value) }
        }
        if (candidates.isEmpty()) {
            val compact = upper.replace(" ", "").replace("\n", "")
            for (p in patterns) p.findAll(compact).forEach { candidates.add(it.value) }
        }
        // 兜底：短行提取丝印代码
        if (candidates.isEmpty()) {
            for (line in lines) {
                val t = line.trim()
                if (noiseWords.any { t.contains(it) }) continue
                val c = t.replace(" ", "")
                if (c.length in 3..5 && (c.matches(Regex("^\\d{3,4}$")) ||
                    c.matches(Regex("^\\d{2}[A-Z]$")) || c.matches(Regex("^\\d+[Rr]\\d+$")))) {
                    candidates.add(c)
                }
            }
        }
        return candidates.toList()
    }

    fun extract(text: String): String? = extractAll(text).firstOrNull()
}
