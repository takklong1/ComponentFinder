package com.example.componentfinder.util

object ModelExtractor {

    private val patterns = listOf(
        Regex("""CC\d{4}[A-Z]{2}(?:NPO|X7R|X5R)[0-9A-Z]{3}\d{3}"""),
        Regex("""RC\d{4}[A-Z]{2}-?\d{2}[0-9A-Z]{3,4}"""),
        Regex("""CL\d{2}[A-Z]\d{3}[A-Z][0-9A-Z]{2}[A-Z]{3}"""),
        Regex("""\d{4}[A-Z]{1,2}\d{3}[A-Z]\d{3}[A-Z]{2}"""),
        Regex("""TCC\d{4}(?:X7R|X5R|NPO|C0G)\d{3}[A-Z]\d{3}[A-Z]{2}"""),
        Regex("""GRM\d{2}[A-Z0-9]{3}[0-9A-Z]{2}\d{3}[A-Z][A-Z0-9]{2}[A-Z0-9]"""),
        Regex("""\b\d{3,4}\b""")
    )

    fun extract(text: String): String? {
        val upper = text.uppercase().replace(" ", "")
        for (p in patterns) {
            p.find(upper)?.let { return it.value }
        }
        return null
    }
}
