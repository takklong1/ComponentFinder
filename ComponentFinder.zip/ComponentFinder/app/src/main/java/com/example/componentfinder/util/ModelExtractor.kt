package com.example.componentfinder.util

object ModelExtractor {

    private val patterns = listOf(
        // YAGEO 电容
        Regex("CC\\d{4}[A-Z]{2}(?:NPO|X7R|X5R)[0-9A-Z]{3}\\d{3}"),
        // YAGEO 电阻
        Regex("RC\\d{4}[A-Z]{2}-?\\d{2}[0-9A-Z]{3,4}"),
        // Samsung
        Regex("CL\\d{2}[A-Z]\\d{3}[A-Z][0-9A-Z]{2}[A-Z]{3}"),
        // CCTC
        Regex("TCC\\d{4}(?:X7R|X5R|NPO|C0G)\\d{3}[A-Z]\\d{3}[A-Z]{2}"),
        // Murata
        Regex("GRM\\d{2}[A-Z0-9]{3}[0-9A-Z]{2}\\d{3}[A-Z][A-Z0-9]{2}[A-Z0-9]"),
        // TDK
        Regex("C\\d{4}(?:X7R|X5R|C0G|NPO|Y5V|X7S)[0-9A-Z]{2}\\d{3}[A-Z][A-Z0-9]{3}"),
        // FH / Walsin 通用
        Regex("\\d{4}[A-Z]{1,2}\\d{3}[A-Z]\\d{3}[A-Z]{2}"),
        // UNI-ROYAL 电阻
        Regex("\\d{4}[A-Z]\\d[A-Z]\\d{4}[A-Z0-9]+")
    )

    fun extract(text: String): String? {
        val upper = text.uppercase()
        for (p in patterns) {
            p.find(upper)?.let { return it.value }
        }
        return null
    }
}
