package com.example.componentfinder.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.core.graphics.toColorInt
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.text.Sp
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.glance.unit.Dp
import com.example.componentfinder.camera.CameraScanActivity

class OcrWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { Content(context) }
    }

    @Composable
    private fun Content(context: Context) {
        val intent = Intent(context, CameraScanActivity::class.java).apply {
            putExtra(CameraScanActivity.EXTRA_MODE, CameraScanActivity.MODE_OCR)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .background("#2196F3".toColorInt())
                .clickable(actionStartActivity(intent))
                .padding(Dp(8f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "拍照识别",
                style = TextStyle(
                    color = ColorProvider(android.graphics.Color.WHITE),
                    fontSize = Sp(14f)
                )
            )
        }
    }
}

class OcrWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = OcrWidget()
}