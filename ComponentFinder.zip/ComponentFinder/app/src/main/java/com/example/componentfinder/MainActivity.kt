package com.example.componentfinder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.componentfinder.ui.navigation.AppNav
import com.example.componentfinder.ui.theme.ComponentFinderTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ComponentFinderTheme {
                AppNav()
            }
        }
    }
}
