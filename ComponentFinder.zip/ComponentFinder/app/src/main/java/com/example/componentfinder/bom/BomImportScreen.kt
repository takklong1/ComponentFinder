package com.example.componentfinder.bom

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BomImportScreen(
    onBack: () -> Unit,
    onDone: () -> Unit,
    vm: BomViewModel = viewModel()
) {
    val context = LocalContext.current
    var textInput by remember { mutableStateOf("") }
    val loading by vm.loading.collectAsState()

    val fileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val content = context.contentResolver
                .openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            textInput = content
            vm.importText(content)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("导入 BOM") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("支持 CSV / 文本粘贴", style = MaterialTheme.typography.bodySmall)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        fileLauncher.launch(arrayOf("text/*", "*/*"))
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("选择文件") }

                OutlinedButton(
                    onClick = { vm.clear(); textInput = "" },
                    modifier = Modifier.weight(1f)
                ) { Text("清空") }
            }

            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                label = { Text("粘贴 BOM 内容") },
                minLines = 8,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { vm.importText(textInput) },
                enabled = textInput.isNotBlank() && !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (loading) CircularProgressIndicator(
                    modifier = Modifier.size(18.dp), strokeWidth = 2.dp
                ) else Text("开始解析")
            }

            val items by vm.items.collectAsState()
            if (items.isNotEmpty()) {
                Text("已解析 ${items.size} 行", style = MaterialTheme.typography.bodyMedium)
                Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) {
                    Text("查看结果")
                }
            }
        }
    }
}
