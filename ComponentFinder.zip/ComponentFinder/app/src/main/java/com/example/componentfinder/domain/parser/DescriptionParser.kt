package com.example.componentfinder.domain.parser

import com.example.componentfinder.domain.model.ComponentSpec

object DescriptionParser {

    fun parse(text: String): List<ComponentSpec> {
        val out = mutableListOf<ComponentSpec>()
        text.split(Regex("[\\r\\n]+")).forEach { line ->
            parseLine(line)?.let { out.add(it) }
        }
        if (out.isEmpty()) parseLine(text)?.let { out.add(it) }
        return out
    }

    private fun parseLine(line: String): ComponentSpec? {
        val s = line.trim()
        if (s.isEmpty() || s.length > 200) return null
        val u = s.uppercase()

        // 找封装（含 R1206 / 1206 等）
        var pkg = "-"
        Regex("\\bR?(0201|0402|0603|0805|1206|1210|1812|2010|2512|3216|3225|4532|6432|1005|1608|2012|5025)\\b")
            .find(u)?.let {
                pkg = it.groupValues[1]
                pkg = when (pkg) {
                    "1005" -> "0402"; "1608" -> "0603"; "2012" -> "0805"
                    "3216" -> "1206"; "3225" -> "1210"; "4532" -> "1812"
                    "5025" -> "2010"; "6432" -> "2512"
                    else -> pkg
                }
            }

        // 精度
        val tol = Regex("±\\s*(\\d+(?:\\.\\d+)?)\\s*%").find(u)
            ?.let { "±${it.groupValues[1]}%" } ?: "-"

        // 阻值
        var resVal = "-"
        // 0Ω / 0R / (000)
        if (u.contains("0Ω") || u.contains("0R ") || u.contains("(000)") || u.contains("0 OHM")) {
            resVal = "0Ω"
        } else {
            Regex("(\\d+(?:\\.\\d+)?)\\s*([KMG]?)\\s*[Ω]").find(u)?.let {
                val n = it.groupValues[1].toDouble()
                val k = it.groupValues[2]
                val ohm = when (k) {
                    "K" -> n * 1000; "M" -> n * 1_000_000; "G" -> n * 1_000_000_000
                    else -> n
                }
                resVal = formatR(ohm)
            }
            // 阻值代码：330K / 1001 / 4R7
            if (resVal == "-") {
                Regex("(\\d{3,4}[RKM]?\\d*)\\b").find(u)?.let {
                    val code = it.groupValues[1]
                    if (code.endsWith("K") || code.endsWith("R") || code.endsWith("M") ||
                        code.length == 3 || code.length == 4) {
                        resVal = CodeMaps.resValue(code)
                    }
                }
            }
        }

        // 容值
        var capVal = "-"
        Regex("(\\d+(?:\\.\\d+)?)\\s*(PF|NF|UF|µF)\\b").find(u)?.let {
            val n = it.groupValues[1].toDouble()
            val unit = it.groupValues[2].replace("µ", "U")
            val pf = when (unit) {
                "PF" -> n; "NF" -> n * 1000; "UF" -> n * 1_000_000
                else -> n
            }
            capVal = formatC(pf)
        }

        // 电压
        val volt = Regex("(\\d+(?:\\.\\d+)?)\\s*(KV|V)\\b").find(u)
            ?.let { "${it.groupValues[1]}${it.groupValues[2]}" } ?: "-"

        // 必须至少有阻值或容值
        val hasR = resVal != "-"
        val hasC = capVal != "-"
        if (!hasR && !hasC) return null

        val isRes = hasR && (u.contains("电阻") || u.contains("RESISTOR") || u.contains("Ω"))
        val isCap = hasC && (u.contains("电容") || u.contains("CAPACITOR"))
        val type = when {
            isRes && !isCap -> "电阻"
            isCap && !isRes -> "电容"
            hasR && !hasC -> "电阻"
            hasC && !hasR -> "电容"
            else -> if (u.contains("电阻")) "电阻" else "电容"
        }
        val value = if (type == "电阻") resVal else capVal
        val material = when {
            type == "电阻" -> "厚膜"
            u.contains("NPO") || u.contains("C0G") -> "NPO (C0G)"
            u.contains("X7R") -> "X7R"
            u.contains("X5R") -> "X5R"
            u.contains("Y5V") -> "Y5V"
            else -> "-"
        }

        return ComponentSpec(
            type = type,
            packageName = pkg,
            value = value,
            tolerance = tol,
            voltage = volt,
            quantity = "-",
            material = material,
            brand = "描述解析"
        )
    }

    private fun formatR(o: Double): String = when {
        o >= 1_000_000 -> "${t(o / 1_000_000)} MΩ"
        o >= 1000 -> "${t(o / 1000)} kΩ"
        else -> "${t(o)} Ω"
    }
    private fun formatC(pf: Double): String = when {
        pf >= 1_000_000 -> "${t(pf / 1_000_000)} µF"
        pf >= 1000 -> "${t(pf / 1000)} nF"
        else -> "${t(pf)} pF"
    }
    private fun t(v: Double): String {
        val r = Math.round(v * 1000.0) / 1000.0
        return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
    }
}
