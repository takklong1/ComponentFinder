package com.example.componentfinder.domain.parser

import com.example.componentfinder.domain.model.ComponentSpec

object DescriptionParser {

    fun parse(text: String): List<ComponentSpec> {
        val out = mutableListOf<ComponentSpec>()
        text.split(Regex("[\\r\\n]+")).forEach { line ->
            parseLine(line)?.let { out.add(it) }
        }
        if (out.isEmpty()) parseLine(text)?.let { out.add(it) }
        return out
    }

    private fun parseLine(line: String): ComponentSpec? {
        val s = line.trim()
        if (s.isEmpty() || s.length > 300) return null
        val u = s.uppercase()

        // 替换中文分号，便于统一处理
        val normalized = u.replace("；", ";").replace("：", ":")

        // 找封装：R0805 / 0805 / 1206 等
        var pkg = "-"
        Regex("\\bR?(0201|0402|0603|0805|1206|1210|1812|2010|2512|1005|1608|2012|3216|3225|4532|5025|6432)\\b")
            .find(normalized)?.let {
                pkg = it.groupValues[1]
                pkg = when (pkg) {
                    "1005" -> "0402"; "1608" -> "0603"; "2012" -> "0805"
                    "3216" -> "1206"; "3225" -> "1210"; "4532" -> "1812"
                    "5025" -> "2010"; "6432" -> "2512"
                    else -> pkg
                }
            }

        // 精度
        val tol = Regex("±\\s*(\\d+(?:\\.\\d+)?)\\s*%").find(normalized)
            ?.let { "±${it.groupValues[1]}%" } ?: "-"

        // 阻值：4.7KΩ / 330KΩ / 0Ω / 4R7
        var resVal = "-"
        if (normalized.contains("0Ω") || normalized.contains("0R") || normalized.contains("(000)")) {
            resVal = "0Ω"
        } else {
            // 带单位：4.7KΩ
            Regex("(\\d+(?:\\.\\d+)?)\\s*([KMG]?)\\s*[ΩΩ]").find(normalized)?.let {
                val n = it.groupValues[1].toDouble()
                val k = it.groupValues[2]
                val ohm = when (k) {
                    "K" -> n * 1000; "M" -> n * 1_000_000; "G" -> n * 1_000_000_000
                    else -> n
                }
                resVal = formatR(ohm)
            }
            // 阻值代码：472 / 330K / 4R7 / 1001
            if (resVal == "-") {
                Regex("(\\d{3,4}[RKM]?\\d*)\\b").find(normalized)?.let {
                    val code = it.groupValues[1]
                    if (code.length == 3 || code.length == 4 || code.endsWith("R") || code.endsWith("K")) {
                        resVal = CodeMaps.resValue(code)
                    }
                }
            }
        }

        // 容值
        var capVal = "-"
        Regex("(\\d+(?:\\.\\d+)?)\\s*(PF|NF|UF|µF)\\b").find(normalized)?.let {
            val n = it.groupValues[1].toDouble()
            val unit = it.groupValues[2].replace("µ", "U")
            val pf = when (unit) {
                "PF" -> n; "NF" -> n * 1000; "UF" -> n * 1_000_000
                else -> n
            }
            capVal = formatC(pf)
        }

        // 电压
        val volt = Regex("(\\d+(?:\\.\\d+)?)\\s*(KV|V)\\b").find(normalized)
            ?.let { "${it.groupValues[1]}${it.groupValues[2]}" } ?: "-"

        // 功率
        val power = Regex("(1/\\d+W|\\d+W)").find(normalized)?.value ?: "-"

        val hasR = resVal != "-"
        val hasC = capVal != "-"
        if (!hasR && !hasC) return null

        val type = when {
            hasR && !hasC -> "电阻"
            hasC && !hasR -> "电容"
            hasR && normalized.contains("电阻") -> "电阻"
            hasC && normalized.contains("电容") -> "电容"
            else -> if (normalized.contains("电阻")) "电阻" else "电容"
        }
        val value = if (type == "电阻") resVal else capVal
        val material = when {
            type == "电阻" -> "厚膜"
            normalized.contains("NPO") || normalized.contains("C0G") -> "NPO (C0G)"
            normalized.contains("X7R") -> "X7R"
            normalized.contains("X5R") -> "X5R"
            normalized.contains("Y5V") -> "Y5V"
            else -> "-"
        }

        return ComponentSpec(
            type = type,
            packageName = pkg,
            value = value,
            tolerance = tol,
            voltage = volt,
            quantity = if (power != "-") power else "-",
            material = material,
            brand = "描述解析"
        )
    }

    private fun formatR(o: Double): String = when {
        o >= 1_000_000 -> "${t(o / 1_000_000)} MΩ"
        o >= 1000 -> "${t(o / 1000)} kΩ"
        else -> "${t(o)} Ω"
    }
    private fun formatC(pf: Double): String = when {
        pf >= 1_000_000 -> "${t(pf / 1_000_000)} µF"
        pf >= 1000 -> "${t(pf / 1000)} nF"
        else -> "${t(pf)} pF"
    }
    private fun t(v: Double): String {
        val r = Math.round(v * 1000.0) / 1000.0
        return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
    }
}
