package com.example.componentfinder.ui.converter

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.componentfinder.domain.parser.SMDCodeParser

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitConverterScreen(onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("单位换算 / 丝印查询") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("输入丝印(104) 或 数值(100nF / 10kΩ)") },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { result = convertSmart(input) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("换算") }

            if (result.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        result,
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("💡 示例", style = MaterialTheme.typography.titleSmall)
                    Text("• 104 → 电容 100nF / 电阻 100kΩ", style = MaterialTheme.typography.bodySmall)
                    Text("• 1001 → 电阻 1kΩ (E96, ±1%)", style = MaterialTheme.typography.bodySmall)
                    Text("• 01B → 电阻 1kΩ (E96 代码, 0603)", style = MaterialTheme.typography.bodySmall)
                    Text("• 100nF → 100000 pF / 0.1 µF", style = MaterialTheme.typography.bodySmall)
                    Text("• 10kΩ → 10000 Ω / 0.01 MΩ", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

private fun convertSmart(input: String): String {
    val s = input.trim().replace(" ", "").uppercase()
    if (s.isEmpty()) return "请输入内容"

    val isSMDCode = s.matches(Regex("^\\d{3,4}$")) ||
            s.matches(Regex("^\\d{2}[A-Z]$")) ||
            s.matches(Regex("^\\d+[Rr]\\d+$"))

    if (isSMDCode) {
        val specs = SMDCodeParser.parseAll(s)
        if (specs.isNotEmpty()) {
            val sb = StringBuilder()
            sb.append("「").append(input).append("」识别为丝印代码：\n\n")
            specs.forEach { spec ->
                sb.append("【").append(spec.type).append("】\n")
                spec.toOrderedList().forEach { (k, v) ->
                    if (v != "-" && v.isNotEmpty()) sb.append("  ").append(k).append("：").append(v).append("\n")
                }
                sb.append("\n")
            }
            sb.append("注：\n")
            sb.append("• 电阻 E24(3位)±5%，E96(4位或代码)±1%\n")
            sb.append("• 电容 104=100nF 等")
            return sb.toString().trim()
        }
    }

    val capRegex = Regex("([\\d.]+)\\s*(pf|nf|uf|µf|f)", RegexOption.IGNORE_CASE)
    val resRegex = Regex("([\\d.]+)\\s*(m?[ωΩ]|m?ohm|k|K|M|r|R)", RegexOption.IGNORE_CASE)

    if (capRegex.containsMatchIn(s)) return convertCap(input)
    if (resRegex.containsMatchIn(s) || s.contains("欧")) return convertRes(input)

    return "无法识别格式。\n示例：\n• 丝印 104 / 1001 / 01B\n• 数值 100nF / 10kΩ / 4R7"
}

private fun fmt(v: Double): String {
    val r = Math.round(v * 1_000_000.0) / 1_000_000.0
    return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
}

private fun convertCap(input: String): String {
    val m = Regex("([\\d.]+)\\s*(pf|nf|uf|µf|f)", RegexOption.IGNORE_CASE).find(input)
        ?: return "格式错误，示例：100nF、1uF、0.1uf"
    val v = m.groupValues[1].toDouble()
    val unit = m.groupValues[2].lowercase().replace("µ", "u")
    val pfValue = when (unit) {
        "pf" -> v
        "nf" -> v * 1000
        "uf" -> v * 1_000_000
        "f" -> v * 1_000_000_000_000
        else -> return "未知单位"
    }
    return "输入：$input\n" +
            "= ${fmt(pfValue)} pF\n" +
            "= ${fmt(pfValue / 1000)} nF\n" +
            "= ${fmt(pfValue / 1_000_000)} µF\n" +
            "= ${fmt(pfValue / 1_000_000_000_000)} F"
}

private fun convertRes(input: String): String {
    val s = input.trim().replace(" ", "").replace("欧", "")
    val m = Regex("([\\d.]+)(m?[ωΩ]|m?ohm|[kK]|[Mm]|[rR])?", RegexOption.IGNORE_CASE).find(s)
        ?: return "格式错误，示例：10kΩ、1M、4R7"
    val v = m.groupValues[1].toDoubleOrNull() ?: return "数值格式错误"
    val rawUnit = m.groupValues[2]
    val ohmValue = when (rawUnit.lowercase()) {
        "mω", "mohm" -> v / 1000
        "k", "kω", "kohm" -> v * 1000
        "m" -> v * 1_000_000
        "r" -> v
        else -> v
    }
    return "输入：$input\n" +
            "= ${fmt(ohmValue)} Ω\n" +
            "= ${fmt(ohmValue / 1000)} kΩ\n" +
            "= ${fmt(ohmValue / 1_000_000)} MΩ"
}
