package com.example.componentfinder.ui.converter

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitConverterScreen(onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("单位换算") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("输入数值 + 单位，如 100nF、10kΩ") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { result = convertCap(input) }) { Text("电容换算") }
                Button(onClick = { result = convertRes(input) }) { Text("电阻换算") }
            }
            if (result.isNotEmpty()) {
                Text("结果：$result", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

private fun fmt(v: Double): String {
    val r = Math.round(v * 1_000_000.0) / 1_000_000.0
    return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
}

private fun convertCap(input: String): String {
    val m = Regex("([\\d.]+)\\s*(pF|nF|µF|uF|pf|nf|uf)", RegexOption.IGNORE_CASE)
        .find(input) ?: return "格式错误，示例：100nF"
    val v = m.groupValues[1].toDouble()
    val unit = m.groupValues[2].lowercase().replace("µ", "u")
    return when (unit) {
        "pf" -> "${fmt(v / 1000)} nF / ${fmt(v / 1_000_000)} µF"
        "nf" -> "${fmt(v * 1000)} pF / ${fmt(v / 1000)} µF"
        "uf" -> "${fmt(v * 1000)} nF / ${fmt(v * 1_000_000)} pF"
        else -> "未知单位"
    }
}

private fun convertRes(input: String): String {
    val m = Regex("([\\d.]+)\\s*(Ω|kΩ|MΩ|mΩ|ohm|k|K|M|m)")
        .find(input) ?: return "格式错误，示例：10kΩ"
    val v = m.groupValues[1].toDouble()
    val unit = m.groupValues[2]
    return when (unit) {
        "Ω", "ohm" -> "${fmt(v / 1000)} kΩ / ${fmt(v / 1_000_000)} MΩ"
        "kΩ", "k", "K" -> "${fmt(v * 1000)} Ω / ${fmt(v / 1000)} MΩ"
        "MΩ", "M" -> "${fmt(v * 1_000_000)} Ω / ${fmt(v * 1000)} kΩ"
        "mΩ", "m" -> "${fmt(v / 1000)} Ω / ${fmt(v / 1_000_000)} kΩ"
        else -> "未知单位"
    }
}
