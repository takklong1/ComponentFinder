package com.example.componentfinder.ui.converter

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitConverterScreen(onBack: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("auto") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("单位换算") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("输入，如 100nF / 10k / 1u / 0.1uf") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = mode == "auto",
                    onClick = { mode = "auto" },
                    label = { Text("自动") }
                )
                FilterChip(
                    selected = mode == "cap",
                    onClick = { mode = "cap" },
                    label = { Text("电容") }
                )
                FilterChip(
                    selected = mode == "res",
                    onClick = { mode = "res" },
                    label = { Text("电阻") }
                )
            }
            Button(
                onClick = {
                    result = when (mode) {
                        "cap" -> convertCap(input)
                        "res" -> convertRes(input)
                        else -> convertAuto(input)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("换算") }

            if (result.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text(result, modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

private fun fmt(v: Double): String {
    val r = Math.round(v * 1_000_000.0) / 1_000_000.0
    return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
}

private fun convertAuto(input: String): String {
    val s = input.trim().lowercase()
    return when {
        s.contains("f") || s.contains("p") || s.contains("n") || s.contains("u") -> convertCap(input)
        s.contains("k") || s.contains("m") || s.contains("r") ||
                s.contains("欧") || s.contains("ω") -> convertRes(input)
        else -> "无法判断类型，请手动选择电容/电阻"
    }
}

private fun convertCap(input: String): String {
    val m = Regex("([\\d.]+)\\s*(pf|nf|uf|µf|f|p|n|u)",
        RegexOption.IGNORE_CASE).find(input)
        ?: return "格式错误，示例：100nF、1uF、0.1uf"
    val v = m.groupValues[1].toDouble()
    val rawUnit = m.groupValues[2].lowercase().replace("µ", "u")
    val unit = when (rawUnit) {
        "p", "pf" -> "pf"
        "n", "nf" -> "nf"
        "u", "uf" -> "uf"
        "f" -> "f"
        else -> return "未知单位"
    }
    val pfValue = when (unit) {
        "pf" -> v
        "nf" -> v * 1000
        "uf" -> v * 1_000_000
        "f" -> v * 1_000_000_000_000
        else -> v
    }
    return "输入：$input\n" +
            "= ${fmt(pfValue)} pF\n" +
            "= ${fmt(pfValue / 1000)} nF\n" +
            "= ${fmt(pfValue / 1_000_000)} µF\n" +
            "= ${fmt(pfValue / 1_000_000_000_000)} F"
}

private fun convertRes(input: String): String {
    val m = Regex("([\\d.]+)\\s*(m?[ωΩ]|m?ohm|k|K|M|R|r|m|欧)?",
        RegexOption.IGNORE_CASE).find(input.replace(" ", ""))
        ?: return "格式错误，示例：10kΩ、1M、4R7"
    val v = m.groupValues[1].toDoubleOrNull() ?: return "数值格式错误"
    val rawUnit = m.groupValues[2].lowercase()
    val ohmValue = when {
        rawUnit.contains("兆") || rawUnit == "m" && input.contains("M") -> v * 1_000_000
        rawUnit == "mω" || rawUnit == "mohm" -> v / 1000
        rawUnit == "k" || rawUnit == "kω" || rawUnit == "kohm" -> v * 1000
        rawUnit == "m" -> v * 1_000_000
        rawUnit.isEmpty() || rawUnit == "ω" || rawUnit == "ohm" || rawUnit == "r" -> v
        else -> v
    }
    return "输入：$input\n" +
            "= ${fmt(ohmValue)} Ω\n" +
            "= ${fmt(ohmValue / 1000)} kΩ\n" +
            "= ${fmt(ohmValue / 1_000_000)} MΩ"
}
